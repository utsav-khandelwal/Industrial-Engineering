# Importing required libraries
import sys
import math
import scipy
from scipy.optimize import minimize
import numpy as np


#  Defining the objective function
def f(x):
	return (x[0]**2 +4*x[2] + math.exp(x[1]**2 + 2*(x[2]**2)))

#  Defining the constraints of objective function
def c1(x):
	return -(x[0] -x[1] +10*x[2] +2)

def c2(x):
	return -x[1] +x[2] -1

# Defining bounds of each variable
b= (-10.0 , 10.0)
bound = (b,b,b)
ineq_cons = {'type': 'ineq', 'fun': c1}
eq_cons = {'type': 'eq', 'fun': c2}
cons = [ineq_cons,eq_cons]
x0=[1,1,1]

# using constrained optimization solvers, SLSQP
res = minimize(f, x0, method='SLSQP', bounds = bound, constraints =cons)

print("Solution using the constrained optimization solvers: ", res.x)