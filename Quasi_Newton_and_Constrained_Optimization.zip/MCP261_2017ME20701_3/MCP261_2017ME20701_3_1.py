# Importing required libraries
import sys
import scipy
import numpy as np
import scipy.optimize 
from scipy.optimize import minimize


#  Defining the objective function
def f(x):
	return 8*(x[0][0]**4) + 3*(x[1][0]**2) - 6*x[0][0]*x[1][0] + 2*x[1][0]

#  Defining the derivative of objective function
def gf(x):
	return np.array([[32*(x[0][0]**3) - 6*x[1][0]], [6*x[1][0]-6*x[0][0]+2]])


# Defining initial condition
xk = np.array([[1],[1]])

# Taking b as I, initially
bk = np.array([[1,0],[0,1]])

# Calculating pk through following equation
pk = -((np.linalg.inv(bk)).dot(gf(xk)))
def h(a):
	return (f(xk + a*pk))

#  Finding alpha-k using Exact line search
res = scipy.optimize.minimize_scalar(h)
a= res.x

# Updating value of x
xk1 = xk + a*pk

# Running loop, conditioning on tolerance and usng exact step length Algo and Scipy function
while(np.linalg.norm(xk1 - xk, ord=np.inf)> 10**(-6)):
	sk = xk1 - xk
	yk = gf(xk1) - gf(xk)
	xk = xk1
	bk = bk + np.divide(np.dot((yk-np.dot(bk,sk)),(yk - np.dot(bk,sk)).transpose()), np.dot((yk-np.dot(bk,sk)).transpose(), sk))
	pk = -((np.linalg.inv(bk)).dot(gf(xk)))
	def h(a):
		return (f(xk + a*pk))
	res = scipy.optimize.minimize_scalar(h)
	a= res.x
	xk1 = xk + a*pk

print("Through quasi-Newton algorithm: ", xk1)

# Verification
def v(x):
	x1 = x[0]
	x2 = x[1]
	return 8*(x1**4) + 3*(x2**2) - 6*x1*x2 + 2*x2

xv = np.array([1, 1])
res = minimize(v, xv, method='nelder-mead',options={'xatol': 1e-8, 'disp': True})
print("Answer verification:",res.x)