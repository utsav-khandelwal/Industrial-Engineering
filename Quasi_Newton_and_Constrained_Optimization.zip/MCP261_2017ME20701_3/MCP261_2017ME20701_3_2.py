# Importing required libraries
import sys
import math
import scipy
from scipy.optimize import minimize
import numpy as np

#  Defining the objective function
def f(x):
	return (x[0]**2 -2*x[0] +4*(x[1]**2) -.03*(x[2]**2) +.04*x[2])

#  Defining the constraints of objective function
def c1(x):
	return x[0] + x[1] + x[2] -2

# Defining bounds of each variable
b= (0, 2)
bound = (b,b,b)
eq_cons = {'type': 'eq', 'fun': c1}
cons = [eq_cons]
x0=[.5, .5, 1]

# using constrained optimization solvers, SLSQP
res = minimize(f, x0, method='SLSQP', bounds = bound, constraints =cons)


print("Solution using the constrained optimization solvers: ",res.x)