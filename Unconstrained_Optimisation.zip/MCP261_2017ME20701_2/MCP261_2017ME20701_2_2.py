import sys
import numpy as np

#Defining the function
def f(x1,x2):
	return 5*(x1**4) + 6*(x2**4) - 6*(x1**2) + 2*x1*x2 + 5*(x2**2)+15*x1 - 7*x2 - 13

#defining the gradient
def gf(x1,x2):
	return np.array([[20*(x1**3) - 12*x1 + 2*x2 +15],[24*(x2**3) + 2*x1 + 10*x2 -7]])

#defining the hessian
def hf(x1,x2):
	return np.array([[60*(x1**2)-12 , 2],[2, 72*(x2**2)+10]])

#applying newtons method algorithm
def newton(f,gf,x0):
	xk = x0 - (np.linalg.inv(hf(x0[0][0], x0[1][0]))).dot(gf(x0[0][0],x0[1][0]))	#xk is the updated value
	while(np.linalg.norm(xk-x0, ord=np.inf)> 10**(-6)):	# Checking the tolerance and reiterating
		x0=xk
		xk = x0 - (np.linalg.inv(hf(x0[0][0], x0[1][0]))).dot(gf(x0[0][0],x0[1][0]))
	return xk

#Defining initial solution
x0=np.array([[1],[1]])


print("Minima by Newton method: ", newton(f,gf,x0))
print("Value of gradient at point on minima: " ,gf(newton(f,gf,x0)[0][0],newton(f,gf,x0)[1][0]))
print("The eigen values of hessian are: " ,np.linalg.eigvals(hf(newton(f,gf,x0)[0][0],newton(f,gf,x0)[1][0])))
print("At point of Minima the gradient value is 0 and eigen values are positive, Therefore this is a point of minima")
