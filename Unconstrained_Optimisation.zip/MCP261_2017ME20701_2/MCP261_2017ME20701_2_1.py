import sys
import numpy as np # importing Numpy library

# Defining the given Function
def f(x):
	return 8*(x[0][0]**4) + 3*(x[1][0]**2) - 6*x[0][0]*x[1][0] + 2*x[1][0]


# Defining the Gradient function
def gf(x):
	return np.array([[32*(x[0][0]**3) - 6*x[1][0]], [6*x[1][0]-6*x[0][0]+2]])

def hf(x):
	return np.array([[96*x[0][0]**2, -6],[-6,6]]) 

# Defining the steepest descent method
def steepest(f,gf,xk):
	u=.2 			# Armijo constant
	a=1				# step length
	while(f(xk-a*gf(xk))>= f(xk)-u*a*((gf(xk).transpose()).dot(gf(xk)))): # Using Armijo Equation to find appropriate a
		a=a/2				# decreasing value to half in each iteration
	y = xk - a*(gf(xk))		# y is the updated value
	while(np.linalg.norm(y-xk, ord=np.inf)> 10**(-6)):	# applying Tolerance bound and continuing till the norm becomes less than 10**(-6)
		xk=y
		a=1
		while(f(xk-a*gf(xk))> f(xk)-u*a*((gf(xk).transpose()).dot(gf(xk)))):
			a=a/2
		y=xk-a*(gf(xk))
	return y

# giving the initial value [1,1]
xk = np.array([[1],[1]])

print("Minima by steepest descent: ", steepest(f,gf,xk))
print("Value of gradient at point on minima: " ,gf(steepest(f,gf,xk)))
print("The eigen values of hessian are: " ,np.linalg.eigvals(hf(steepest(f,gf,xk))))
print("At point of Minima the gradient value is 0 and eigen values are positive, Therefore this is a point of minima")

