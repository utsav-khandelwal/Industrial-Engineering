import sys
import math
import numpy

#defing the objective function
def f(x):
	return math.sin(x) - 3*x*math.exp(-(x**3))

# Hard coding Derivative of f(x)
def derivative(x):
	return math.cos(x) - 3*math.exp(-(x**3)) + 9*(x**3)*math.exp(-(x**3))

#Algo of newton's method taking tolerance as 10^-6
def Newtons(x0):
	x1=x0-f(x0)/derivative(x0)
	if(abs(f(x1)-f(x0))>10**(-6)):
		x0=x1
		return Newtons(x0)
	else:
		return x0

x0=1 # Taking initial guess to be 1
print(Newtons(x0))