import sys
import numpy as np

#defing the objective function
def f(x):
	return 3*(x**3)-12*(x**2)+5*x+4

# Hard coding Derivative of f(x)
def derivative(x):
	return 9*(x**2)-24*x+5

#Applying bisection method with tolerance= 10^-2
def bisection(a,b):
	while(abs(f(b)-f(a)) >10**(-2)):
		p=(a+b)/2		# p is the point of bisection
		if(f(p)==0):
			break		# i.e p is the root
		elif(f(p)*f(a)<0):
			b=p
		else:
			a=p
	return p

# Now taking initial guesses a & b
a=-10
b=10
print("Root From Bisection Method: ", bisection(a,b))


#Applying Newtons method with tolerance= 10^-6
def Newtons(x0):
	x1=x0-f(x0)/derivative(x0)
	if(abs(f(x1)-f(x0))>10**(-6)):
		x0=x1
		return Newtons(x0)
	else:
		return x0

# Refining the solution of bisection method through Newtons method
x0= bisection(a,b)
print("Root from Newton Method: ", Newtons(x0))


# verify:
coeff=[3,-12,5,4]
root= np.roots(coeff)
print("Solution set: ", root)