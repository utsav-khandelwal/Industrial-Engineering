import xlrd                         
import numpy

#please enter the file name according to your computer
loc=("/home/utsav/Documents/MCP261_2017ME20701_4/Ex_4_TPM_Q.xlsx")      # Path of file
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0) 

def func(a,n) :                                       # Function for adding G.P, to get M(i,j)
    sum = numpy.identity(18)
    i = 1
    while i < n : 
        sum = sum + numpy.linalg.matrix_power(a,i)  
        i = i + 1    
    return sum

def cost(k):                                        # Function to find out the total cost in each state for 1 stay
    total_cost=0
    i=5
    while i<12:
        total_cost=(total_cost)+(sheet.cell_value(i, k))    # Column summation from excel
        i=i+1
    return total_cost

s = (18,18)                                         # TPM size
i=4

matrix=numpy.zeros(s)                               # Initialising the TPM

while i<22:                                         # Loop for generation the TPM 
    j=4
    while j<22:      
        matrix[i-4][j-4]=(sheet.cell_value(i, j))
        j=j+1
    i=i+1
    
n = 60
first_row=func(matrix,n)[0]   
print("Average time spent in each state",first_row)         # average time spent in each state = first row of the sum matrix

k=24
sum=0
while k<42:                                             # Finding the average cost in each state over 5 years
    sum=sum+cost(k)*first_row[k-24]
    k=k+1
    
print("Average total cost spent by a patient over 5 years=",sum)