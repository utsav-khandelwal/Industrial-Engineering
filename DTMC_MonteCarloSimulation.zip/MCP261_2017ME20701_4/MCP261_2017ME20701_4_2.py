import xlrd
import numpy
import random
random.seed(1234)

# Enter the file name according to your computer

loc=("/home/utsav/Documents/MCP261_2017ME20701_4/Ex_4_TPM_Q.xlsx")      # Input the path of file

wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 
total_cost = numpy.zeros(1000, dtype = float)       # Initialising the ramdon values obtained in array form

def um(a,n) :                                       # Function for adding G.P, to get M(i,j)
    sum = numpy.identity(18)
    i = 1
    while i < n : 
        sum = sum + numpy.linalg.matrix_power(a,i)
        i = i + 1    
    return sum

def cost(k):                                        # Function to find out the total cost in each state for 1 stay
    total_cost=0
    i=5
    while i<12:
        total_cost=(total_cost)+(sheet.cell_value(i, k))    # Column summation from excel
        i=i+1
    return total_cost

def random_generator(a,b):                          # Random number generator function
    return random.gauss(a,b)                        # a,b are the mean and variance corresponding to each state

def random_cost(k):                                 # Function to find out the total cost in each state for 1 stay
    total_cost=0
    i=5
    while i<12:
        total_cost=(total_cost)+(sheet.cell_value(i, k))    # Column summation from excel
        i=i+1
    u=total_cost                                    # Mean and variance calculated for each state(column) 
    s=0.05*total_cost
    return random_generator(u,s)                    

s = (18,18)                                         # TPM size
i=4

matrix=numpy.zeros(s)                               # Initialising the TPM

while i<22:                                         # For creting TPM
    j=4
    while j<22:      
        matrix[i-4][j-4]=(sheet.cell_value(i, j))
        j=j+1
    i=i+1

n = 60
first_row=um(matrix,n)[0]                           # First row of sum matrix

j=0
while j<1000:                                       # To find the average cost in each state over 5 years    
    k=24
    sum = 0
    while k<42:
        sum=sum + first_row[k-24]*random_cost(k)    # Changing the total cost 
        k=k+1
    total_cost[j] = sum 
    j=j+1

print("Mean is: ",numpy.mean(total_cost))                            # printing mean   
print("Variance is: ",numpy.std(total_cost))                         # printing variance