import xlrd
import numpy
import random
import scipy
import matplotlib.pyplot as plt
from scipy import stats
random.seed(1234)

#please enter the file name according to your computer
loc=("/home/utsav/Documents/MCP261_2017ME20701_4/Ex_4_TPM_Q.xlsx")      #path of file
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 
total_cost = numpy.zeros(1000, dtype = float)

def um(a,n) :     
    sum = numpy.identity(18)
    i = 1
    while i < n : 
        sum = sum + numpy.linalg.matrix_power(a,i)
        i = i + 1    
    return sum


# Creating a cost function to calculate cost
def cost(k):
    total_cost=0
    i=5
    while i<12:
        total_cost=(total_cost)+(sheet.cell_value(i, k))
        i=i+1
    return total_cost

# Creating a Random Generator Function
def random_generator(a,b):
    return random.gauss(a,b)

# Creating a Random cost Function
def random_cost(k):
    total_cost=0
    i=5
    while i<12:
        total_cost=(total_cost)+(sheet.cell_value(i, k))
        i=i+1
    u=total_cost
    s=0.05*total_cost
    return random_generator(u,s)

s = (18,18)
i=4

matrix=numpy.zeros(s)

while i<22:
    j=4
    while j<22:
        matrix[i-4][j-4]=(sheet.cell_value(i, j))
        j=j+1
    i=i+1
n = 60
first_row=um(matrix,n)[0]

j=0

while j<1000: 
    k=24
    sum = 0
    while k<42:
        sum=sum + first_row[k-24]*random_cost(k)
        k=k+1
    total_cost[j] = sum 
    j=j+1

plt.hist(total_cost, 100)                           # Plotting of the total cost obtained in the previous question using 100 lines
plt.show()      

k=0
dist_names = ['norm','gamma','lognorm','expon','beta','triang']         # Distributions for which KS test needs to be done
D_statistic = numpy.zeros(6, dtype = float)                             # Initialising the array

while k<=5:                                                             # Storing the D-statistic value for each distribution
    distr = getattr(stats, dist_names[k])
    D_statistic[k]=abs(scipy.stats.kstest(total_cost,dist_names[k],distr.fit(total_cost))[0])
    k=k+1
    
y=numpy.argmin(D_statistic)                # Storing minimum index
print("The best fit is: ",dist_names[y]," distribution")